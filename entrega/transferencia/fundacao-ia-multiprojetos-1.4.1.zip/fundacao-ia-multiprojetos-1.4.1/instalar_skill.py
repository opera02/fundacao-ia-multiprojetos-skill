#!/usr/bin/env python3
"""Instala, atualiza, verifica ou remove a skill fundacao-ia-multiprojetos neste computador.

Convenção (a mesma já usada pelas outras skills deste perfil):
  cópia física   ~/.agents/skills/fundacao-ia-multiprojetos        (Codex e outros hosts Agent Skills)
  ligação        ~/.claude/skills/fundacao-ia-multiprojetos  ->  cópia física
                 (Windows: junção de diretório, sem exigir administrador; Linux/macOS: link simbólico)

  python instalar_skill.py instalar   --origem <pasta-da-skill | pacote.skill>
  python instalar_skill.py atualizar  --origem <...>      (guarda a versão anterior em ~/.agents/skills-anteriores/)
  python instalar_skill.py verificar [--origem <...>]    (ligação; com --origem, compara os hashes)
  python instalar_skill.py remover                        (pede --confirmar; remove a ligação, a cópia e a
                                                           instalação manual desta skill em ~/.claude/skills)

Somente arquivos locais; nada é baixado. Saída em JSON.
Requer Python 3.10 ou posterior, conferido ANTES de qualquer alteração. A junção do Windows é
reconhecida também sem `os.path.isjunction` (que só existe a partir do 3.12), pela marca de ponto
de montagem do `lstat` — assim verificar, atualizar e remover funcionam no 3.10/3.11.
`remover` relata cada caminho e sai com código 1 se algo ficar no lugar; arquivo somente leitura
não o interrompe. `verificar` informa se o SQLite tem o FTS5 com o tokenizador do kit da fundação:
é só informativo e não entra em `ok` (a skill instalada não depende dele; o kit, sim).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sqlite3
import stat
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

NOME = "fundacao-ia-multiprojetos"
AGENTS = Path.home() / ".agents" / "skills" / NOME
CLAUDE = Path.home() / ".claude" / "skills" / NOME
ANTERIORES = Path.home() / ".agents" / "skills-anteriores"  # versões substituídas por atualizar
IGNORAR = shutil.ignore_patterns("__pycache__", "*.pyc", "evals")


def hashes(raiz: Path) -> dict[str, str]:
    return {p.relative_to(raiz).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(raiz.rglob("*")) if p.is_file() and "__pycache__" not in p.parts}


def origem_como_pasta(origem: Path, tmp: Path) -> Path:
    if origem.is_dir():
        if not (origem / "SKILL.md").exists():
            raise SystemExit(f"{origem} não contém SKILL.md")
        return origem
    with zipfile.ZipFile(origem) as z:
        z.extractall(tmp)
    pasta = tmp / NOME
    if not (pasta / "SKILL.md").exists():
        raise SystemExit("pacote sem a pasta fundacao-ia-multiprojetos/SKILL.md na raiz")
    return pasta


def e_ligacao(p: Path) -> bool:
    """Link simbólico ou junção do Windows. `os.path.isjunction` só existe a partir do Python 3.12;
    no 3.10/3.11 a junção é reconhecida pela marca de ponto de montagem do `lstat` (F17)."""
    if p.is_symlink():
        return True
    is_junction = getattr(os.path, "isjunction", None)  # Python 3.12+
    if is_junction is not None:
        return bool(is_junction(p))
    if os.name != "nt":
        return False
    try:
        st = os.lstat(p)
    except OSError:
        return False
    return bool(getattr(st, "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT) and \
        getattr(st, "st_reparse_tag", None) == stat.IO_REPARSE_TAG_MOUNT_POINT


def ligar() -> str:
    CLAUDE.parent.mkdir(parents=True, exist_ok=True)
    if CLAUDE.exists() or e_ligacao(CLAUDE):
        if e_ligacao(CLAUDE) and CLAUDE.resolve() == AGENTS.resolve():
            return "ligacao-ja-existia"
        raise SystemExit(f"{CLAUDE} já existe e não aponta para {AGENTS}; resolva manualmente")
    if os.name == "nt":
        r = subprocess.run(["cmd", "/c", "mklink", "/J", str(CLAUDE), str(AGENTS)], capture_output=True, text=True,
                           errors="replace")  # mensagem do cmd vem na página de código do console
        if r.returncode != 0:
            raise SystemExit(f"falha ao criar junção: {r.stdout} {r.stderr}")
        return "juncao-criada"
    CLAUDE.symlink_to(AGENTS, target_is_directory=True)
    return "link-simbolico-criado"


def fts5_do_kit() -> bool:
    """O kit da fundação cria as tabelas FTS5 com este tokenizador (SQLite 3.27+); o mesmo teste do
    `scripts/inspecionar_ambiente.py`. Só informativo: não entra em `ok`."""
    con = sqlite3.connect(":memory:")
    try:
        con.execute("CREATE VIRTUAL TABLE t USING fts5(x, tokenize='unicode61 remove_diacritics 2')")
        return True
    except sqlite3.Error:
        return False
    finally:
        con.close()


def verificar(referencia: Path | None = None) -> dict:
    res = {"copia": str(AGENTS), "copia_existe": (AGENTS / "SKILL.md").exists(),
           "ligacao": str(CLAUDE), "ligacao_ok": e_ligacao(CLAUDE) and CLAUDE.resolve() == AGENTS.resolve(),
           "skill_md_legivel_pela_ligacao": (CLAUDE / "SKILL.md").exists()}
    if referencia is not None and res["copia_existe"]:
        a, b = hashes(referencia), hashes(AGENTS)
        res["arquivos"] = len(b)
        res["divergentes"] = sorted(k for k in set(a) | set(b) if a.get(k) != b.get(k))
    res["ok"] = all(res[k] for k in ("copia_existe", "ligacao_ok", "skill_md_legivel_pela_ligacao")) and \
        not res.get("divergentes")
    res["informativo"] = {"sqlite": sqlite3.sqlite_version, "fts5_unicode61_remove_diacritics_2": fts5_do_kit(),
                          "nota": "o kit da fundação precisa desse FTS5; não entra em ok"}
    return res


def nome_declarado(pasta: Path) -> str | None:
    """`name` do cabeçalho do SKILL.md da pasta, ou None se não houver um legível."""
    try:
        linhas = (pasta / "SKILL.md").read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeDecodeError):
        return None
    if not linhas or linhas[0].strip() != "---":
        return None
    for linha in linhas[1:]:
        if linha.strip() == "---":
            break
        if linha.startswith("name:"):
            return linha.split(":", 1)[1].strip().strip("\"'")
    return None


def apagar_arvore(pasta: Path) -> None:
    """`shutil.rmtree` que limpa o atributo somente leitura e tenta de novo; qualquer outra falha, ou a
    mesma se persistir, sobe para quem chamou (nada é engolido)."""
    def tornar_gravavel(func, caminho, erro):
        erro = erro[1] if isinstance(erro, tuple) else erro  # onerror passa exc_info; onexc, a exceção
        if not isinstance(erro, PermissionError):
            raise erro
        os.chmod(caminho, stat.S_IWRITE)
        func(caminho)
    if sys.version_info >= (3, 12):
        shutil.rmtree(pasta, onexc=tornar_gravavel)
    else:
        shutil.rmtree(pasta, onerror=tornar_gravavel)  # `onexc` só existe a partir do 3.12


def planejar_remocao() -> list[dict]:
    """O que `remover` faz com cada caminho; a mesma lista serve à prévia e à execução."""
    plano = []
    if e_ligacao(CLAUDE):
        plano.append({"caminho": str(CLAUDE), "acao": "remover", "tipo": "ligação",
                      "aponta_para": os.path.realpath(CLAUDE)})
    elif CLAUDE.is_dir():
        if nome_declarado(CLAUDE) == NOME:
            plano.append({"caminho": str(CLAUDE), "acao": "remover", "tipo": "pasta desta skill (instalação manual)"})
        else:
            plano.append({"caminho": str(CLAUDE), "acao": "manter", "tipo": "pasta",
                          "motivo": f"o SKILL.md dela não declara name: {NOME}"})
    elif CLAUDE.exists():
        plano.append({"caminho": str(CLAUDE), "acao": "manter", "tipo": "arquivo",
                      "motivo": "não é ligação nem pasta desta skill"})
    if e_ligacao(AGENTS):
        plano.append({"caminho": str(AGENTS), "acao": "remover", "tipo": "ligação",
                      "aponta_para": os.path.realpath(AGENTS)})
    elif AGENTS.exists():
        plano.append({"caminho": str(AGENTS), "acao": "remover", "tipo": "cópia"})
    return plano


def remover(plano: list[dict]) -> dict:
    removidos, mantidos, falhas = [], [], []
    for item in plano:
        caminho = Path(item["caminho"])
        if item["acao"] != "remover":
            mantidos.append(item)
            continue
        try:
            if e_ligacao(caminho):
                os.rmdir(caminho) if os.name == "nt" else caminho.unlink()  # só a ligação, nunca o alvo
            else:
                apagar_arvore(caminho)
            removidos.append(item)
        except OSError as e:
            falhas.append({**item, "erro": f"{type(e).__name__}: {e}"})
    restam = [str(p) for p in (CLAUDE, AGENTS) if os.path.lexists(p)]
    return {"removido": not restam, "removidos": removidos, "mantidos": mantidos, "falhas": falhas,
            "restam": restam}


PYTHON_MINIMO = (3, 10)  # do instalador; o núcleo e as integrações têm requisitos próprios (README-ENTREGA)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("acao", choices=["instalar", "atualizar", "verificar", "remover"])
    ap.add_argument("--origem", type=Path)
    ap.add_argument("--confirmar", action="store_true")
    a = ap.parse_args()
    if tuple(sys.version_info[:2]) < PYTHON_MINIMO:
        # Pré-verificação ANTES de qualquer alteração: nada é copiado nem ligado (F17).
        print(json.dumps({"erro": f"o instalador exige Python {PYTHON_MINIMO[0]}.{PYTHON_MINIMO[1]} ou posterior "
                                  f"(encontrado {sys.version_info[0]}.{sys.version_info[1]}); nada foi alterado"},
                         ensure_ascii=False))
        return 2
    if a.acao == "verificar":
        if a.origem:
            with tempfile.TemporaryDirectory() as td:
                ref = Path(td) / "ref"
                shutil.copytree(origem_como_pasta(a.origem.resolve(), Path(td)), ref, ignore=IGNORAR)
                res = verificar(ref)
        else:
            res = verificar()
            res["aviso"] = "sem --origem, os hashes não foram comparados"
        print(json.dumps(res, ensure_ascii=False, indent=2))
        return 0 if res["ok"] else 1
    if a.acao == "remover":
        plano = planejar_remocao()
        if not a.confirmar:
            print(json.dumps({"erro": "remoção exige --confirmar",
                              "removeria": [i["caminho"] for i in plano if i["acao"] == "remover"],
                              "manteria": [i for i in plano if i["acao"] != "remover"]}, ensure_ascii=False))
            return 1
        res = remover(plano)
        print(json.dumps(res, ensure_ascii=False, indent=2))
        return 0 if res["removido"] else 1
    if not a.origem:
        ap.error("informe --origem")
    with tempfile.TemporaryDirectory() as td:
        pasta = origem_como_pasta(a.origem.resolve(), Path(td))
        passos = []
        if AGENTS.exists():
            if a.acao == "instalar":
                print(json.dumps({"erro": f"{AGENTS} já existe; use 'atualizar'"}, ensure_ascii=False))
                return 1
            # Fora da pasta de skills: lá, a cópia anterior (mesmo name no SKILL.md) seria lida como outra skill.
            anterior = ANTERIORES / f"{NOME}-{time.strftime('%Y%m%d-%H%M%S')}"
            anterior.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(AGENTS), str(anterior))
            passos.append(f"versão anterior guardada em {anterior}")
        AGENTS.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(pasta, AGENTS, ignore=IGNORAR)
        passos.append("cópia instalada")
        passos.append(ligar())
        ref = Path(td) / "ref"
        shutil.copytree(pasta, ref, ignore=IGNORAR)
        res = verificar(ref)
    res["passos"] = passos
    print(json.dumps(res, ensure_ascii=False, indent=2))
    return 0 if res["ok"] else 1


if __name__ == "__main__":
    for _s in (sys.stdout, sys.stderr):
        try:
            _s.reconfigure(encoding="utf-8")
        except (AttributeError, ValueError):
            pass
    raise SystemExit(main())
