#!/usr/bin/env python3
"""Testes de caracterização ("golden master") para adaptar projetos existentes (Fluxo B).

Grava o comportamento ATUAL de um programa para entradas conhecidas e depois
compara o comportamento após a mudança. Compara saída padrão, saída de erro,
código de término e (opcional) os arquivos produzidos numa pasta de saída.

  gravar   --entradas "dir/*.json" --saida golden.json [--cwd DIR] [--pasta-saida DIR]
           [--ignorar REGEX ...] [--timeout 30] -- programa arg1 {entrada} ...
  comparar --golden golden.json [--cwd DIR] [--pasta-saida DIR] -- programa arg1 {entrada} ...

`{entrada}` é substituído pelo caminho de cada entrada. O comando é passado como
lista (sem shell), evitando interpretar dados como comandos. Use --ignorar para
neutralizar campos voláteis (ex.: datas) antes da comparação.
Diferenças -> código 1. Uma diferença pode ser regressão OU mudança intencional:
registre a decisão no plano de adaptação, não ajuste o golden silenciosamente.
"""

from __future__ import annotations

import argparse
import glob
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path


def norm(text: str, patterns: list[str]) -> str:
    text = text.replace("\r\n", "\n")
    for p in patterns:
        text = re.sub(p, "<IGNORADO>", text)
    return text


def snapshot_dir(path: Path | None) -> dict:
    if not path or not path.exists():
        return {}
    return {p.relative_to(path).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(path.rglob("*")) if p.is_file()}


def run_case(cmd: list[str], entrada: str, cwd: Path | None, out_dir: Path | None, patterns: list[str],
             timeout: int) -> dict:
    argv = [a.replace("{entrada}", entrada) for a in cmd]
    try:
        p = subprocess.run(argv, capture_output=True, cwd=str(cwd) if cwd else None, timeout=timeout)
        stdout = norm(p.stdout.decode("utf-8", "replace"), patterns)
        stderr = norm(p.stderr.decode("utf-8", "replace"), patterns)
        code = p.returncode
    except subprocess.TimeoutExpired:
        stdout, stderr, code = "", "TIMEOUT", "timeout"
    return {"entrada": entrada, "codigo": code, "stdout": stdout[:20000], "stderr": stderr[:4000],
            "arquivos": snapshot_dir(out_dir)}


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    # O comando vem depois de "--"; separar antes do argparse evita que as opções
    # sejam engolidas por um posicional do tipo REMAINDER.
    opts, cmd = (argv[:argv.index("--")], argv[argv.index("--") + 1:]) if "--" in argv else (argv, [])
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("acao", choices=["gravar", "comparar"])
    ap.add_argument("--entradas")
    ap.add_argument("--saida", type=Path)
    ap.add_argument("--golden", type=Path)
    ap.add_argument("--cwd", type=Path)
    ap.add_argument("--pasta-saida", type=Path)
    ap.add_argument("--ignorar", action="append", default=[])
    ap.add_argument("--timeout", type=int, default=30)
    args = ap.parse_args(opts)
    if not cmd:
        ap.error("informe o comando após --")
    if args.acao == "gravar" and (not args.entradas or not args.saida):
        ap.error("gravar exige --entradas e --saida")
    if args.acao == "comparar" and not args.golden:
        ap.error("comparar exige --golden")
    if args.acao == "gravar":
        files = sorted(glob.glob(args.entradas))
        if not files:
            ap.error("nenhuma entrada encontrada")
        cases = [run_case(cmd, f, args.cwd, args.pasta_saida, args.ignorar, args.timeout) for f in files]
        golden = {"schema_version": "fundacao.golden/1", "comando": cmd, "ignorar": args.ignorar, "casos": cases}
        args.saida.parent.mkdir(parents=True, exist_ok=True)
        args.saida.write_text(json.dumps(golden, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps({"casos_gravados": len(cases), "saida": str(args.saida)}, ensure_ascii=False))
        return 0
    golden = json.loads(args.golden.read_text(encoding="utf-8"))
    diffs = []
    for case in golden["casos"]:
        now = run_case(cmd, case["entrada"], args.cwd, args.pasta_saida, golden.get("ignorar", []), args.timeout)
        changed = [k for k in ("codigo", "stdout", "stderr", "arquivos") if now[k] != case[k]]
        if changed:
            diffs.append({"entrada": case["entrada"], "campos_divergentes": changed,
                          "antes": {k: case[k] for k in changed}, "depois": {k: now[k] for k in changed}})
    print(json.dumps({"casos": len(golden["casos"]), "divergencias": diffs}, ensure_ascii=False, indent=2))
    return 1 if diffs else 0


if __name__ == "__main__":
    for _s in (sys.stdout, sys.stderr):
        try:
            _s.reconfigure(encoding="utf-8")
        except (AttributeError, ValueError):
            pass
    raise SystemExit(main())
