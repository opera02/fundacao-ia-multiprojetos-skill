#!/usr/bin/env python3
"""Instala ou atualiza o kit de referência numa raiz AUTORIZADA, de forma idempotente.

- Arquivo ausente: copia.  Idêntico: ignora.  Diferente: NÃO sobrescreve
  (preserva alteração local) e relata o conflito para decisão.
- `--atualizar`: substitui os arquivos diferentes, guardando antes a versão do destino em
  `registry/kit_backup/<data>/` (retorno = copiar de volta) — use só com referência
  recuperável feita e decisão registrada (fluxo C6).
- Nunca copia bancos, caches ou segredos; não executa código do destino.
- Registra em registry/kit_install.json a versão EFETIVAMENTE instalada (lida do destino)
  e marca `atualizacao_incompleta` quando sobram conflitos.

Uso: python instalar_kit.py --destino RAIZ [--simular] [--atualizar]
Depois: cd RAIZ && python -m fundacao init --admin <identidade-do-titular>
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

KIT = Path(__file__).resolve().parents[1] / "assets" / "fundacao-kit"
SKIP_PARTS = {"__pycache__", ".pytest_cache"}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def kit_version(base: Path) -> str:
    init = base / "fundacao" / "__init__.py"
    if not init.exists():
        return "ausente"
    for line in init.read_text(encoding="utf-8").splitlines():
        if line.startswith("KIT_VERSION"):
            return line.split("=", 1)[1].strip().strip('"')
    return "desconhecida"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--destino", type=Path, required=True)
    ap.add_argument("--simular", action="store_true", help="só relata o que faria")
    ap.add_argument("--atualizar", action="store_true",
                    help="substitui arquivos diferentes, guardando a versão anterior para retorno")
    args = ap.parse_args()
    dest = args.destino.resolve()
    versao_antes = kit_version(dest)
    carimbo = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup_dir = dest / "registry" / "kit_backup" / carimbo
    copied, identical, conflicts, replaced = [], [], [], []
    for src in sorted(KIT.rglob("*")):
        rel = src.relative_to(KIT)
        if not src.is_file() or set(rel.parts) & SKIP_PARTS or src.suffix in (".pyc", ".sqlite"):
            continue
        target = dest / rel
        if target.exists():
            if sha(target) == sha(src):
                identical.append(rel.as_posix())
            elif args.atualizar:
                replaced.append({"path": rel.as_posix(), "sha256_anterior": sha(target), "sha256_novo": sha(src)})
                if not args.simular:
                    guardado = backup_dir / rel
                    guardado.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(target, guardado)
                    shutil.copy2(src, target)
            else:
                conflicts.append(rel.as_posix())
            continue
        copied.append({"path": rel.as_posix(), "sha256": sha(src)})
        if not args.simular:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, target)
    record = {
        "kit_origem": kit_version(KIT), "versao_antes": versao_antes,
        "kit_version": kit_version(dest) if not args.simular else versao_antes,
        "instalado_em": datetime.now(timezone.utc).isoformat(),
        "copiados": copied, "identicos": len(identical), "conflitos_preservados": conflicts,
        "substituidos": replaced,
        "backup_dos_substituidos": str(backup_dir) if replaced and not args.simular else None,
        "atualizacao_incompleta": bool(conflicts),
        "simulacao": args.simular,
    }
    if not args.simular:
        reg = dest / "registry"
        reg.mkdir(parents=True, exist_ok=True)
        log = reg / "kit_install.json"
        history = json.loads(log.read_text(encoding="utf-8")) if log.exists() else []
        history.append(record)
        log.write_text(json.dumps(history, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(record, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    for _s in (sys.stdout, sys.stderr):
        try:
            _s.reconfigure(encoding="utf-8")
        except (AttributeError, ValueError):
            pass
    raise SystemExit(main())
