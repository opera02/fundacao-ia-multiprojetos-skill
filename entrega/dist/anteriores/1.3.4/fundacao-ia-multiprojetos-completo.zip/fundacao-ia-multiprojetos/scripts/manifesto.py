#!/usr/bin/env python3
"""Manifesto de arquivos com hash e comparação (livro A05, A33, A35; Apêndice E).

Um hash identifica conteúdo; não é backup e não prova que o conteúdo é correto.
Arquivos com aparência de segredo são listados como excluídos e NÃO são lidos.

  criar      --raiz DIR --saida manifesto.json [--texto-canonico] [--rotulo ID]
  verificar  --raiz DIR --manifesto manifesto.json   (diferenças -> código 1)
  comparar   --a m1.json --b m2.json                  (diferenças -> código 1)

--texto-canonico: para .md/.txt/.json/.py/.yaml calcula o hash após normalizar
UTF-8, LF e NFC (o mesmo arquivo com CRLF e LF dá o mesmo hash).
"""

from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import sys
import unicodedata
from datetime import datetime, timezone
from pathlib import Path

EXCLUDE_DIRS = {".git", "__pycache__", ".venv", "venv", "node_modules", ".mypy_cache", ".pytest_cache"}
SECRET_GLOBS = [".env", ".env.*", "*.pem", "*.key", "*.pfx", "*.p12", "id_rsa*", "*credentials*", "*secret*",
                "auth.json", "*.kdbx"]
TEXT_SUFFIXES = {".md", ".txt", ".json", ".py", ".yaml", ".yml", ".toml", ".csv", ".html", ".sql"}


def is_secret(name: str) -> bool:
    low = name.lower()
    return any(fnmatch.fnmatch(low, g) for g in SECRET_GLOBS)


def file_hash(path: Path, canonical: bool) -> str:
    data = path.read_bytes()
    if canonical and path.suffix.lower() in TEXT_SUFFIXES:
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            return hashlib.sha256(data).hexdigest()
        text = text.lstrip("\ufeff").replace("\r\n", "\n").replace("\r", "\n")
        data = unicodedata.normalize("NFC", text).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def build(root: Path, canonical: bool, extra_excludes: list[str]) -> dict:
    files, excluded = [], []
    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root)
        if any(part in EXCLUDE_DIRS for part in rel.parts[:-1]) or not path.is_file():
            continue
        if is_secret(path.name) or any(fnmatch.fnmatch(rel.as_posix(), g) for g in extra_excludes):
            excluded.append({"path": rel.as_posix(), "motivo": "segredo/credencial ou exclusão explícita"})
            continue
        try:
            files.append({"path": rel.as_posix(), "size": path.stat().st_size, "sha256": file_hash(path, canonical)})
        except OSError as exc:
            excluded.append({"path": rel.as_posix(), "motivo": f"ilegível: {type(exc).__name__}"})
    return {"schema_version": "fundacao.manifest/1", "raiz": root.name,
            "criado_em": datetime.now(timezone.utc).isoformat(), "hash_alg": "sha256",
            "texto_canonico": canonical, "arquivos": files, "excluidos": excluded,
            "aviso": "manifesto identifica conteúdo; não é cópia de segurança"}


def diff(a: dict, b: dict) -> dict:
    ma = {f["path"]: f["sha256"] for f in a["arquivos"]}
    mb = {f["path"]: f["sha256"] for f in b["arquivos"]}
    return {
        "alterados": sorted(p for p in ma.keys() & mb.keys() if ma[p] != mb[p]),
        "ausentes": sorted(ma.keys() - mb.keys()),
        "novos": sorted(mb.keys() - ma.keys()),
    }


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("criar"); c.add_argument("--raiz", type=Path, required=True)
    c.add_argument("--saida", type=Path, required=True); c.add_argument("--texto-canonico", action="store_true")
    c.add_argument("--rotulo"); c.add_argument("--excluir", action="append", default=[])
    v = sub.add_parser("verificar"); v.add_argument("--raiz", type=Path, required=True)
    v.add_argument("--manifesto", type=Path, required=True)
    k = sub.add_parser("comparar"); k.add_argument("--a", type=Path, required=True); k.add_argument("--b", type=Path, required=True)
    args = ap.parse_args()
    if args.cmd == "criar":
        m = build(args.raiz.resolve(), args.texto_canonico, args.excluir)
        m["rotulo"] = args.rotulo
        args.saida.parent.mkdir(parents=True, exist_ok=True)
        args.saida.write_text(json.dumps(m, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps({"arquivos": len(m["arquivos"]), "excluidos": len(m["excluidos"]), "saida": str(args.saida)},
                         ensure_ascii=False))
        return 0
    if args.cmd == "verificar":
        ref = json.loads(args.manifesto.read_text(encoding="utf-8"))
        cur = build(args.raiz.resolve(), ref.get("texto_canonico", False), [])
        d = diff(ref, cur)
    else:
        d = diff(json.loads(args.a.read_text(encoding="utf-8")), json.loads(args.b.read_text(encoding="utf-8")))
    print(json.dumps(d, ensure_ascii=False, indent=2))
    return 1 if any(d.values()) else 0


if __name__ == "__main__":
    for _s in (sys.stdout, sys.stderr):
        try:
            _s.reconfigure(encoding="utf-8")
        except (AttributeError, ValueError):
            pass
    raise SystemExit(main())
