"""Estado de referência, backup e restauração (livro A05, A18, A35; 3.0 R13).

- Banco: cópia consistente pela API de backup do SQLite (nunca copiar o arquivo
  em uso sem o -wal) + PRAGMA integrity_check + comparação lógica. A cópia sai do modo
  WAL (abrir para conferir não cria `-wal`/`-shm`) e o manifesto guarda o SHA-256 do
  arquivo do banco e o resumo lógico; a verificação confere os dois.
- Arquivos: manifesto com hash e tamanho; credenciais nunca entram.
- Restauração sempre em destino separado; antes de liberar o uso, reaplicar o que o
  registro protegido guarda depois do snapshot: retiradas (senão a fonte ou a memória
  retirada "ressuscita") e revogações de acesso (senão quem perdeu o acesso o recupera).
- O registro protegido (`state/retiradas.jsonl`) tem identidade própria, criada pelo `init`
  e anotada no manifesto: a restauração recusa registro de outra fundação ou recriado.
"""

from __future__ import annotations

import json
import re
import shutil
import sqlite3
from pathlib import Path

from .canon import canonical_json, sha256_file, sha256_text
from .contracts import ValidationError
from .db import connect, transaction, uri_somente_leitura, utcnow
from .ids import new_id

EXCLUDE_PARTS = {"__pycache__", ".venv", "node_modules", ".git"}
EXCLUDE_NAMES = {".env", "state.sqlite", "state.sqlite-wal", "state.sqlite-shm"}
FILE_DIRS = ("fundacao", "registry", "templates", "projects")
REGISTRO = "registro"  # tipo da linha de identidade do registro protegido
SCHEMA_REGISTRO = "fundacao.retiradas/1"
MARCA_NAO_LIBERADA = "restauracao-nao-liberada.json"
# Campos exigidos por tipo de linha (sem `entity_type` = fonte, formato gravado pela 1.1.0).
_CAMPOS = {
    "source": ("entity_id", "decided_by", "decided_at"),
    "memory": ("entity_id", "decided_by", "decided_at"),
    "acl_revoke": ("entity_id", "principal", "resource", "action", "decided_by", "decided_at"),
    "component_disable": ("entity_id", "component_id", "decided_by", "decided_at"),
}
# Arquivos que o sistema operacional cria sozinho numa pasta (Explorer em pasta de rede, Finder):
# não contam como "extras" na verificação e não são restaurados.
METADADOS_DO_SO = ("Thumbs.db", "ehthumbs.db", "desktop.ini", ".DS_Store")
# O que a restauração NÃO reaplica (vai na resposta, para conferência da administração).
NAO_REAPLICADO = [
    "concessões de acesso posteriores à cópia (reconceder é decisão da administração)",
    "habilitação de componente posterior à cópia (o componente volta desligado)",
    "alterações em arquivos posteriores à cópia, como registry/route_policy.json: confira à mão",
]


def _files(root: Path):
    for top in FILE_DIRS:
        base = root / top
        if not base.exists():
            continue
        for path in sorted(base.rglob("*")):
            if path.is_file() and not (set(path.relative_to(root).parts) & EXCLUDE_PARTS) \
                    and path.name not in EXCLUDE_NAMES and not path.name.endswith(".pyc"):
                yield path


def logical_summary(db_path: Path, *, copia: bool = False) -> dict:
    """Resumo lógico lido em modo somente leitura (não grava nada no banco conferido). `copia=True`
    (cópia de backup): leitura imutável, só do arquivo do banco, sem criar `-wal`/`-shm`."""
    con = sqlite3.connect(uri_somente_leitura(db_path, imutavel=copia), uri=True)
    try:
        tables = [r[0] for r in con.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'"
            " AND name NOT LIKE 'fts_%' ORDER BY name")]
        counts = {t: con.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0] for t in tables}
        integrity = con.execute("PRAGMA integrity_check").fetchone()[0]
        user_version = con.execute("PRAGMA user_version").fetchone()[0]
    finally:
        con.close()
    return {"tables": counts, "integrity_check": integrity, "user_version": user_version}


# ------------------------------------------------------------------ registro protegido
def _ilegivel(linha: int, motivo: str) -> ValidationError:
    return ValidationError("registro de retiradas ilegível", linha=linha, motivo=motivo)


def _ler_registro(log_path: Path, *, estrito: bool = False) -> tuple[str | None, list[tuple[str, dict]]]:
    """Lê e valida o registro inteiro antes de qualquer uso. Devolve a identidade e as linhas de
    retirada/revogação (texto e objeto), sem a linha de identidade. Tipo de linha desconhecido
    (gravado por um kit mais novo) só é recusado com `estrito=True` — a restauração, que precisa
    reaplicar tudo; contar linhas (backup) e preencher retiradas (init) o aceitam."""
    path = Path(log_path)
    if not path.exists():
        return None, []
    try:
        texto = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        raise _ilegivel(0, "não é texto UTF-8") from None
    log_id, linhas = None, []
    for n, line in enumerate(texto.splitlines(), start=1):
        if not line.strip():
            continue
        try:
            rec = json.loads(line)
        except json.JSONDecodeError:
            raise _ilegivel(n, "JSON inválido") from None
        if not isinstance(rec, dict):
            raise _ilegivel(n, "linha não é objeto")
        tipo = rec.get("entity_type", "source")
        if tipo == REGISTRO:
            if log_id is not None or not isinstance(rec.get("log_id"), str) or not rec["log_id"]:
                raise _ilegivel(n, "identidade repetida ou vazia")
            log_id = rec["log_id"]
            continue
        campos = _CAMPOS.get(tipo)
        if campos is None:
            if estrito or not isinstance(tipo, str) or not isinstance(rec.get("entity_id"), str):
                raise _ilegivel(n, "tipo de linha desconhecido (registro de kit mais novo? atualize o kit)")
            linhas.append((line, rec))
            continue
        if any(not isinstance(rec.get(c), str) or not rec[c] for c in campos):
            raise _ilegivel(n, "campo obrigatório ausente")
        if tipo in ("source", "memory") and not isinstance(rec.get("reason"), str):
            raise _ilegivel(n, "motivo ausente")
        if tipo == "source" and not re.fullmatch(r".+@\d+", rec["entity_id"]):
            raise _ilegivel(n, "fonte sem versão (esperado id@versão)")
        afetadas = rec.get("affected", [])
        if tipo == "memory" and not (isinstance(afetadas, list) and all(isinstance(a, str) for a in afetadas)):
            raise _ilegivel(n, "derivados da memória em formato inválido")
        linhas.append((line, rec))
    return log_id, linhas


def default_tombstone_log(con: sqlite3.Connection) -> Path | None:
    """Registro protegido padrão: `<raiz>/state/retiradas.jsonl`, ao lado do banco."""
    for row in con.execute("PRAGMA database_list"):
        if row[1] == "main" and row[2]:
            return Path(row[2]).parent / "retiradas.jsonl"
    return None


def ensure_tombstone_log(log_path: Path) -> str:
    """Garante o registro protegido com identidade própria (o `init` chama). Registro de kit
    anterior, sem identidade, recebe-a numa linha nova ao final: nada é reescrito."""
    path = Path(log_path)
    log_id, _ = _ler_registro(path)
    if log_id:
        return log_id
    log_id = new_id("reg")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as fh:
        fh.write(canonical_json({"entity_type": REGISTRO, "log_id": log_id, "criado_em": utcnow(),
                                 "schema_version": SCHEMA_REGISTRO}) + "\n")
    return log_id


def tombstone_state(log_path: Path) -> dict:
    """Identidade, quantidade de linhas de retirada/revogação e hash da última (cobertura)."""
    log_id, linhas = _ler_registro(log_path)
    return {"log_id": log_id, "linhas": len(linhas),
            "ultima_sha256": sha256_text(linhas[-1][0]) if linhas else None}


def read_tombstone_log(log_path: Path) -> list[dict]:
    return [rec for _, rec in _ler_registro(log_path)[1]]


def append_tombstone_log(log_path: Path, record: dict) -> None:
    """Registro protegido, mantido FORA do backup, para reaplicação. Registro novo nasce com identidade."""
    log_path = Path(log_path)
    if not log_path.exists() or log_path.stat().st_size == 0:
        ensure_tombstone_log(log_path)
    with log_path.open("a", encoding="utf-8", newline="\n") as fh:
        fh.write(canonical_json(record) + "\n")


def backfill_tombstone_log(con: sqlite3.Connection, log_path: Path) -> list[str]:
    """Acrescenta ao registro as retiradas que estão no banco e faltam nele (ex.: memórias retiradas
    com kit anterior à 1.2.0). Só entidades-raiz (versões de fonte e memórias): trechos e caches
    derivados são refeitos pela limpeza na reaplicação. Revogações antigas não ficam no banco e
    não podem ser preenchidas."""
    _, linhas = _ler_registro(log_path)
    conhecidas: set[str] = set()
    for _, rec in linhas:
        conhecidas.add(rec["entity_id"])
        conhecidas.update(rec.get("affected") or [])
    novas = []
    for row in con.execute("SELECT entity_id, project_id, decided_by, reason, decided_at FROM tombstone"
                           " ORDER BY decided_at, entity_id").fetchall():
        ent = row[0]
        if ent in conhecidas:
            continue
        if con.execute("SELECT 1 FROM memory_item WHERE memory_id = ?", (ent,)).fetchone():
            afetadas = [ent] + [r[0] for r in con.execute(
                "WITH RECURSIVE d(id) AS (SELECT child_id FROM dependency WHERE parent_id = ?"
                " UNION SELECT x.child_id FROM dependency x JOIN d ON x.parent_id = d.id) SELECT id FROM d",
                (ent,)).fetchall()]
            rec = {"entity_type": "memory", "entity_id": ent, "affected": afetadas}
        else:
            sid, _, ver = ent.rpartition("@")
            if not (sid and ver.isdigit() and con.execute(
                    "SELECT 1 FROM source_version WHERE source_id = ? AND version = ?", (sid, int(ver))).fetchone()):
                continue  # derivado (trecho, cache): refeito pela limpeza da fonte
            rec = {"entity_type": "source", "entity_id": ent}
        rec.update(project_id=row[1], decided_by=row[2] or "desconhecido", reason=row[3] or "",
                   decided_at=row[4] or utcnow(), origem="preenchido-pelo-init")
        append_tombstone_log(log_path, rec)
        conhecidas.update([ent, *rec.get("affected", [])])
        novas.append(ent)
    return novas


def _cobre(linhas: list[tuple[str, dict]], conhecido: dict) -> bool:
    """O registro informado precisa conter as linhas conhecidas quando a cópia foi feita."""
    n = int(conhecido.get("linhas") or 0)
    if not n:
        return True
    return len(linhas) >= n and sha256_text(linhas[n - 1][0]) == conhecido.get("ultima_sha256")


# ------------------------------------------------------------------ backup
def create_backup(root: Path, dest: Path, label: str) -> dict:
    root, dest = Path(root), Path(dest)
    if dest.exists() and any(dest.iterdir()):
        raise FileExistsError("destino de backup não vazio: não substitua uma referência anterior")
    # O registro protegido precisa existir, legível e com identidade, ANTES da cópia: é ele que a
    # restauração confere. Fundação de kit anterior: rode `init` (cria a identidade e preenche).
    retiradas = tombstone_state(root / "state" / "retiradas.jsonl")
    if not retiradas["log_id"]:
        raise ValidationError("registro de retiradas ausente ou sem identidade nesta raiz: rode `init` antes do backup")
    dest.mkdir(parents=True, exist_ok=True)
    src_db = root / "state" / "state.sqlite"
    files = []
    if src_db.exists():
        (dest / "state").mkdir()
        src = sqlite3.connect(str(src_db))
        dst = sqlite3.connect(str(dest / "state" / "state.sqlite"))
        try:
            src.backup(dst)  # cópia consistente mesmo com o banco em uso
            dst.execute("PRAGMA journal_mode = DELETE")  # cópia fora do WAL: conferir não cria -wal/-shm
        finally:
            dst.close()
            src.close()
    for path in _files(root):
        rel = path.relative_to(root)
        target = dest / "files" / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
        files.append({"path": rel.as_posix(), "size": path.stat().st_size, "sha256": sha256_file(path)})
    manifest = {
        "schema_version": "fundacao.backup/1",
        "label": label,
        "created_at": utcnow(),
        "db": logical_summary(dest / "state" / "state.sqlite", copia=True) if src_db.exists() else None,
        "db_sha256": sha256_file(dest / "state" / "state.sqlite") if src_db.exists() else None,
        "files": files,
        # Identidade do registro e linhas conhecidas no momento da cópia: na restauração, o registro
        # informado precisa ter a mesma identidade e alcançar pelo menos este ponto.
        "retiradas": retiradas,
        "excluded": sorted(EXCLUDE_NAMES | EXCLUDE_PARTS),
        "credentials": "não incluídas; restabelecer pelo mecanismo próprio de cada provedor",
    }
    (dest / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest


def _ler_manifesto(backup_dir: Path) -> dict:
    """Manifesto com a estrutura esperada; senão, erro do contrato (não traceback)."""
    m = json.loads((Path(backup_dir) / "manifest.json").read_text(encoding="utf-8"))
    ok = (isinstance(m, dict) and isinstance(m.get("files"), list)
          and all(isinstance(f, dict) and isinstance(f.get("path"), str) and isinstance(f.get("sha256"), str)
                  for f in m["files"])
          and isinstance(m.get("db"), (dict, type(None))) and isinstance(m.get("retiradas"), (dict, type(None))))
    if not ok:
        raise ValidationError("manifesto da cópia com estrutura inválida: não é uma cópia desta fundação")
    return m


def verify_backup(backup_dir: Path) -> dict:
    """Confere a cópia contra o manifesto: hash de cada arquivo; no banco, o SHA-256 do arquivo
    (cópias da 1.3.1 em diante), a integridade e o resumo lógico (contagem por tabela e
    `user_version`). Banco trocado, tabela esvaziada ou banco ausente = não confere.
    Limite: manifesto e banco ficam na mesma pasta; quem puder reescrever os dois forja a cópia
    (proteja as cópias: 3-2-1-1-0, com uma imutável)."""
    backup_dir = Path(backup_dir)
    manifest = _ler_manifesto(backup_dir)
    changed, missing = [], []
    for f in manifest["files"]:
        path = backup_dir / "files" / f["path"]
        if not path.exists():
            missing.append(f["path"])
        elif sha256_file(path) != f["sha256"]:
            changed.append(f["path"])
    # Arquivo na cópia que o manifesto não lista também não confere: seria restaurado (até código
    # em fundacao/) sem que ninguém o tivesse copiado.
    base = backup_dir / "files"
    listados = {f["path"] for f in manifest["files"]}
    soltos = sorted(rel for rel in (p.relative_to(base).as_posix() for p in base.rglob("*") if p.is_file())
                    if rel not in listados) if base.is_dir() else []
    do_so = [rel for rel in soltos if rel.rsplit("/", 1)[-1] in METADADOS_DO_SO]
    extras = [rel for rel in soltos if rel not in do_so]
    db = backup_dir / "state" / "state.sqlite"
    esperado = manifest.get("db")
    db_check, db_problemas = None, []
    if db.exists():
        if manifest.get("db_sha256") and sha256_file(db) != manifest["db_sha256"]:
            db_problemas.append("hash do banco diferente do manifesto")
        db_check = logical_summary(db, copia=True)
        if db_check["integrity_check"] != "ok":
            db_problemas.append("integrity_check falhou")
        if esperado:
            tabelas = esperado.get("tables") or {}
            diferentes = sorted(t for t in set(tabelas) | set(db_check["tables"])
                                if tabelas.get(t) != db_check["tables"].get(t))
            if diferentes:
                db_problemas.append("contagens diferentes do manifesto: " + ", ".join(diferentes))
            if db_check["user_version"] != esperado.get("user_version"):
                db_problemas.append("user_version diferente do manifesto")
    elif esperado:
        db_problemas.append("banco ausente na cópia")
    resultado = {"ok": not changed and not missing and not extras and not db_problemas,
                 "changed": changed, "missing": missing, "extras": extras, "db": db_check,
                 "db_problemas": db_problemas}
    if do_so:
        resultado["ignorados_do_so"] = do_so  # metadados do sistema: nem conferidos nem restaurados
    if db.exists() and not manifest.get("db_sha256"):
        resultado["aviso"] = ("cópia anterior à 1.3.1: o banco é conferido só por integridade e contagens "
                              "(o manifesto não tem db_sha256); uma troca com as mesmas contagens passaria — "
                              "faça um backup novo")
    return resultado


# ------------------------------------------------------------------ restauração
def restore(backup_dir: Path, target_root: Path, tombstone_log: Path | None, *,
            aceitar_registro_nao_comprovado: bool = False, executado_por: str = "restauracao") -> dict:
    """Restaura em destino NOVO, reaplica o que o registro guarda e só então libera.

    Não libera (released=false), e não copia nada, quando: a cópia não confere; o registro não foi
    informado, não existe, é ilegível, tem identidade diferente da anotada na cópia (outra fundação
    ou registro recriado) ou não alcança as linhas conhecidas no momento da cópia. Cópia sem
    identidade anotada (kit anterior à 1.3.0) e sem retiradas só libera com aceitação explícita,
    que fica na resposta e na trilha. Reaplica por tipo: fonte (`id@versão`, com limpeza dos
    derivados), memória (com os derivados registrados) e revogação de acesso (só as posteriores
    à cópia). Cada reaplicação vira evento na trilha restaurada. Até liberar, o destino carrega
    `state/restauracao-nao-liberada.json`, e a CLI recusa usar essa raiz."""
    backup_dir, target_root = Path(backup_dir), Path(target_root)
    if target_root.exists() and any(target_root.iterdir()):
        raise FileExistsError("restaure em diretório novo ou vazio; nunca sobre a origem")
    check = verify_backup(backup_dir)

    def nao_liberar(reason: str) -> dict:
        return {"released": False, "reason": reason, "check": check}

    if not check["ok"]:
        return nao_liberar("backup íntegro? não")
    if tombstone_log is None:
        return nao_liberar("registro de retiradas indisponível: não liberar")
    if not Path(tombstone_log).is_file():
        return nao_liberar("registro de retiradas inexistente no caminho informado: não liberar")
    manifest = _ler_manifesto(backup_dir)
    try:
        log_id, linhas = _ler_registro(Path(tombstone_log), estrito=True)  # validado antes de copiar
    except ValidationError as exc:
        return nao_liberar(f"registro de retiradas ilegível (linha {exc.details.get('linha')}: "
                           f"{exc.details.get('motivo')}): não liberar")
    conhecido = manifest.get("retiradas") or {}
    ressalva = None
    if conhecido.get("log_id"):
        if log_id != conhecido["log_id"]:
            if not aceitar_registro_nao_comprovado:
                return nao_liberar("registro de retiradas com identidade diferente da anotada na cópia "
                                   "(outra fundação ou registro recriado): não liberar")
            ressalva = "identidade do registro diferente da anotada na cópia; aceito por decisão explícita"
    elif not conhecido.get("linhas"):
        if not aceitar_registro_nao_comprovado:
            return nao_liberar("cópia sem identidade do registro e sem retiradas para conferir (kit anterior à "
                               "1.3.0): nada prova que este registro é desta fundação; confira-o e use a "
                               "aceitação explícita")
        ressalva = "cópia sem identidade do registro; registro aceito por decisão explícita"
    if not _cobre(linhas, conhecido):
        return nao_liberar("registro de retiradas não alcança as retiradas da cópia "
                           "(outro registro ou registro truncado): não liberar")
    posicao = int(conhecido.get("linhas") or 0)  # linhas já refletidas no banco copiado

    shutil.copytree(backup_dir / "files", target_root, dirs_exist_ok=True,  # destino novo ou vazio
                    ignore=shutil.ignore_patterns(*METADADOS_DO_SO))
    (target_root / "state").mkdir(parents=True, exist_ok=True)
    marca = target_root / "state" / MARCA_NAO_LIBERADA
    marca.write_text(json.dumps({"copia": manifest.get("label"), "inicio": utcnow(),
                                 "situacao": "restauração em andamento ou não liberada: não use esta raiz"},
                                ensure_ascii=False), encoding="utf-8")
    shutil.copy2(backup_dir / "state" / "state.sqlite", target_root / "state" / "state.sqlite")
    con = connect(target_root / "state" / "state.sqlite")
    reapplied = []
    try:
        from . import events, revisions  # import tardio evita ciclo
        from .auth import Principal, resource_project, scope_of
        from .knowledge import KnowledgeService
        system = Principal(executado_por, "processo-de-restauracao")

        def evento(rec: dict, tipo: str) -> None:
            events.emit(con, "restore_reapplied", project_id=rec.get("project_id"), subject=system.principal_id,
                        payload={"tipo": tipo, "entidade": rec["entity_id"], "decidido_por": rec["decided_by"],
                                 "decidido_em": rec["decided_at"], "copia": manifest.get("label")})

        for idx, (_, rec) in enumerate(linhas):
            tipo = rec.get("entity_type", "source")
            entity = rec["entity_id"]
            if tipo == "acl_revoke":
                if idx < posicao:
                    continue  # anterior à cópia: já refletida no banco copiado
                with transaction(con):
                    apagadas = con.execute("DELETE FROM acl WHERE subject = ? AND resource = ? AND action = ?",
                                           (rec["principal"], rec["resource"], rec["action"])).rowcount
                    if apagadas:
                        revisions.bump(con, scope_of(rec["resource"]), "policy_rev")
                        evento(rec, tipo)
                if apagadas:
                    reapplied.append(entity)
                continue
            if tipo == "component_disable":
                if idx < posicao:
                    continue  # anterior à cópia: o arquivo copiado já está desligado
                comp = target_root / "registry" / "components" / f"{rec['component_id']}.json"
                if comp.is_file():
                    entrada = json.loads(comp.read_text(encoding="utf-8"))
                    if entrada.get("enabled"):
                        entrada["enabled"] = False
                        tmp = comp.with_suffix(".tmp")
                        tmp.write_text(json.dumps(entrada, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
                        tmp.replace(comp)
                        evento(rec, tipo)
                        reapplied.append(entity)
                continue
            if tipo == "memory":
                ids = [entity] + [a for a in rec.get("affected", []) if a != entity]
                novos = [i for i in ids if not con.execute(
                    "SELECT 1 FROM tombstone WHERE entity_id = ?", (i,)).fetchone()]
                if not novos:
                    continue
                with transaction(con):
                    for i in novos:
                        con.execute("INSERT INTO tombstone VALUES (?,?,?,?,?,?)",
                                    (i, rec.get("project_id"), rec["decided_by"], rec["reason"], rec["decided_at"],
                                     "done"))
                        con.execute("UPDATE memory_item SET status = 'withdrawn' WHERE memory_id = ?", (i,))
                    evento(rec, tipo)
                reapplied.append(entity)
                continue
            if con.execute("SELECT 1 FROM tombstone WHERE entity_id = ?", (entity,)).fetchone():
                continue
            source_id, version = entity.rsplit("@", 1)
            with transaction(con):
                con.execute(
                    "INSERT INTO tombstone VALUES (?,?,?,?,?,?)",
                    (entity, rec.get("project_id"), rec["decided_by"], rec["reason"], rec["decided_at"], "pending"),
                )
                con.execute(
                    "UPDATE source_version SET status = 'withdrawn', is_current = 0 WHERE source_id = ? AND version = ?",
                    (source_id, int(version)),
                )
                if rec.get("project_id"):
                    revisions.bump(con, resource_project(rec["project_id"]), "corpus_rev")
                evento(rec, tipo)
            KnowledgeService(target_root, con, system).cleanup(entity)
            reapplied.append(entity)
        events.emit(con, "restore_completed", subject=system.principal_id,
                    payload={"copia": manifest.get("label"), "registro": log_id, "reaplicadas": len(reapplied),
                             **({"ressalva": ressalva} if ressalva else {})})
        summary = logical_summary(target_root / "state" / "state.sqlite")
    finally:
        con.close()
    released = summary["integrity_check"] == "ok"
    if released:
        destino_log = target_root / "state" / "retiradas.jsonl"
        if Path(tombstone_log).resolve() != destino_log.resolve():
            shutil.copy2(tombstone_log, destino_log)  # a fundação restaurada segue com o mesmo registro
        marca.unlink()
    result = {"released": released, "reapplied": reapplied, "registro": log_id, "nao_reaplicado": NAO_REAPLICADO,
              "db": summary, "check": check}
    if ressalva:
        result["ressalva"] = ressalva
    if check.get("aviso"):
        result["aviso_copia"] = check["aviso"]
    from .. import KIT_VERSION  # import tardio: versão do kit que está restaurando
    kit_copia = _versao_do_kit(target_root)
    if kit_copia and kit_copia != KIT_VERSION:
        # A raiz restaurada roda o kit que veio na cópia; o registro protegido pode ter tipos mais novos.
        result["kit_da_copia"] = kit_copia
        result["acao_necessaria"] = (f"a raiz restaurada traz o kit {kit_copia} da cópia (este é o {KIT_VERSION}); "
                                     "antes de usá-la, atualize o kit nela (instalar_kit.py --destino <destino> "
                                     "--atualizar) e rode `python -m fundacao init`")
    alvo = str(target_root.resolve())
    if alvo.startswith("\\\\?\\UNC\\") or (alvo.startswith("\\\\") and not alvo.startswith("\\\\?\\")):
        result["aviso_destino"] = ("destino em pasta de rede: serve para conferir; para usar a fundação, restaure em "
                                   "disco local (o SQLite em WAL não deve operar num compartilhamento de rede)")
    return result


def _versao_do_kit(raiz: Path) -> str | None:
    init = Path(raiz) / "fundacao" / "__init__.py"
    if not init.is_file():
        return None
    m = re.search(r'KIT_VERSION\s*=\s*"([^"]+)"', init.read_text(encoding="utf-8"))
    return m.group(1) if m else None
