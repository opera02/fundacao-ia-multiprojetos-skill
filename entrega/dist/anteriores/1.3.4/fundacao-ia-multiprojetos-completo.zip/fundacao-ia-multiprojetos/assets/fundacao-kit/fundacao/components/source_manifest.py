"""Componente `source_manifest` (livro A11): manifesto de fontes autorizadas.

Recebe identificadores de documentos (nunca caminhos livres), resolve-os pelo
catálogo do projeto e devolve caminho relativo, tamanho e hash. Não altera
fontes, não chama provedores e não grava memória. Arquivo inacessível aparece
como erro explícito, sem hash inventado.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

COMPONENT_VERSION = "0.1.0"


def _contained(root: Path, rel: str) -> Path | None:
    root_r = root.resolve()
    cand = (root_r / rel).resolve()
    try:
        cand.relative_to(root_r)
    except ValueError:
        return None
    return cand


def run(request: dict) -> dict:
    project_dir = Path(request["project_dir"])
    data_dir = project_dir / "data"
    catalog = json.loads((data_dir / "catalog.json").read_text(encoding="utf-8"))
    files, errors = [], []
    for doc_id in request["payload"].get("document_ids", []):
        rel = catalog.get(doc_id)
        if rel is None:
            errors.append({"document_id": doc_id, "error": "E_NOT_IN_CATALOG"})
            continue
        path = _contained(data_dir, rel)
        if path is None:
            errors.append({"document_id": doc_id, "error": "E_PATH_ESCAPE"})
            continue
        if not path.is_file():
            errors.append({"document_id": doc_id, "error": "E_UNREADABLE"})
            continue
        data = path.read_bytes()
        files.append({
            "document_id": doc_id,
            "path": path.relative_to(data_dir.resolve()).as_posix(),
            "size": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
        })
    return {
        "component_version": COMPONENT_VERSION,
        "project_id": request["project_id"],
        "files": files,
        "errors": errors,
    }
