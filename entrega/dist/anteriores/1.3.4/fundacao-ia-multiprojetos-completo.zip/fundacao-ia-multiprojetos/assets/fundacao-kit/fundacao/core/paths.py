"""Identificadores e contenção de caminhos.

Pastas separadas organizam, mas não isolam. Toda leitura passa por
`contained()` e pela autorização do serviço (livro, A07; Path.resolve não
autentica ninguém).
"""

from __future__ import annotations

import re
from pathlib import Path

from .contracts import PathEscape, ValidationError

ID_RE = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,38}[a-z0-9])?$")
WINDOWS_RESERVED = {
    "con", "prn", "aux", "nul",
    *(f"com{i}" for i in range(1, 10)),
    *(f"lpt{i}" for i in range(1, 10)),
}


def validate_id(value: str, kind: str = "identificador") -> str:
    """Aceita somente a forma canônica; não normaliza silenciosamente."""
    if not isinstance(value, str):
        raise ValidationError(f"{kind} deve ser texto")
    if value != value.strip():
        raise ValidationError(f"{kind} com espaços nas bordas: use a forma canônica")
    if not ID_RE.match(value) or "--" in value:
        raise ValidationError(
            f"{kind} inválido: use 1-40 caracteres [a-z0-9-], sem hífen nas pontas ou duplo",
            value=value,
        )
    if value in WINDOWS_RESERVED:
        raise ValidationError(f"{kind} usa nome reservado do Windows", value=value)
    return value


def contained(root: Path, candidate: Path) -> Path:
    """Resolve `candidate` e garante que permaneça dentro de `root` (inclui links)."""
    root_r = Path(root).resolve()
    cand = Path(candidate)
    if not cand.is_absolute():
        cand = root_r / cand
    cand_r = cand.resolve()
    try:
        cand_r.relative_to(root_r)
    except ValueError:
        raise PathEscape("caminho fora da raiz autorizada", root=str(root_r.name)) from None
    return cand_r
