"""Registro e ciclo de vida de componentes (livro A11, A34).

Descoberta, instalação, habilitação, saúde e autorização são estados distintos.
`discover()` só lê o registro JSON — nunca importa nem executa o componente.
`dispatch()` confere habilitação e autorização ANTES de iniciar o componente e
executa-o em subprocesso com timeout real (no Windows não é possível
interromper com segurança uma função no mesmo processo).
"""

from __future__ import annotations

import importlib.util
import json
import os
import sqlite3
import subprocess
import sys
from pathlib import Path
from typing import Any

from . import events
from .auth import Policy, Principal, resource_project
from .contracts import (
    SCHEMAS, ComponentDisabled, DependencyUnavailable, FundacaoError, NotFound,
    ValidationError, require_fields,
)
from .db import transaction, utcnow
from .paths import validate_id
from .projects import project_root

REGISTRY_FIELDS = (
    "schema_version", "component_id", "version", "kind", "enabled", "entrypoint",
    "allowed_projects", "permissions", "timeout_seconds",
)
KINDS = {"tool", "adapter", "hook", "mcp_server", "skill", "plugin", "workflow", "service"}


def registry_dir(root: Path) -> Path:
    return Path(root) / "registry" / "components"


def validate_entry(entry: dict) -> dict:
    require_fields(entry, ("schema_version", "component_id", "version", "kind", "entrypoint"), "registro")
    if entry["schema_version"] != SCHEMAS["component"]:
        raise ValidationError("schema_version de componente não suportado")
    validate_id(entry["component_id"].replace("_", "-"), "component_id")
    if entry["kind"] not in KINDS:
        raise ValidationError("kind desconhecido", kind=entry["kind"])
    if not isinstance(entry.get("enabled"), bool):
        raise ValidationError("enabled deve ser booleano")
    if ":" not in entry["entrypoint"]:
        raise ValidationError("entrypoint deve ter a forma modulo:funcao")
    if not isinstance(entry.get("allowed_projects"), list):
        raise ValidationError("allowed_projects deve ser lista")
    if not isinstance(entry.get("timeout_seconds"), int) or entry["timeout_seconds"] <= 0:
        raise ValidationError("timeout_seconds deve ser inteiro positivo")
    return entry


def discover(root: Path) -> list[dict]:
    """Inventário sem efeitos: lê JSON, valida e informa estado. Não importa código."""
    found = []
    for path in sorted(registry_dir(root).glob("*.json")):
        entry = validate_entry(json.loads(path.read_text(encoding="utf-8")))
        missing = [d for d in entry.get("requires_modules", []) if importlib.util.find_spec(d) is None]
        found.append({
            "component_id": entry["component_id"],
            "version": entry["version"],
            "kind": entry["kind"],
            "installed": True,
            "enabled": entry["enabled"],
            "health": "dependencia_ausente" if missing else "nao_consultada",
            "missing_dependencies": missing,
            "allowed_projects": entry["allowed_projects"],
            "purpose": entry.get("purpose", ""),
        })
    return found


def load_entry(root: Path, component_id: str) -> dict:
    path = registry_dir(root) / f"{component_id}.json"
    if not path.exists():
        raise NotFound("componente desconhecido", component_id=component_id)
    return validate_entry(json.loads(path.read_text(encoding="utf-8")))


def set_enabled(root: Path, con: sqlite3.Connection, admin: Principal, component_id: str,
                enabled: bool) -> dict:
    Policy(con).require(admin, "admin", "foundation")
    path = registry_dir(root) / f"{component_id}.json"
    entry = load_entry(root, component_id)
    entry["enabled"] = enabled
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(entry, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    events.emit(con, "component_enabled" if enabled else "component_disabled",
                subject=admin.principal_id, payload={"component_id": component_id,
                                                     "version": entry["version"]})
    if not enabled:
        # Desativação vai para o registro protegido (fora do backup): restaurar uma cópia anterior
        # a reaplica; senão, o componente desligado voltaria ligado.
        from .backup import append_tombstone_log  # import tardio evita ciclo
        append_tombstone_log(Path(root) / "state" / "retiradas.jsonl", {
            "entity_type": "component_disable", "entity_id": f"componente:{component_id}",
            "component_id": component_id, "decided_by": admin.principal_id, "decided_at": utcnow()})
    return entry


def _record(con: sqlite3.Connection, entry: dict, project_id: str | None, subject: str,
            outcome: str) -> None:
    with transaction(con):
        con.execute(
            "INSERT INTO dispatch (component_id, component_version, project_id, subject, outcome, ts)"
            " VALUES (?,?,?,?,?,?)",
            (entry["component_id"], entry["version"], project_id, subject, outcome, utcnow()),
        )


def dispatch_count(con: sqlite3.Connection, component_id: str, outcome: str = "executed") -> int:
    return con.execute(
        "SELECT COUNT(*) FROM dispatch WHERE component_id = ? AND outcome = ?",
        (component_id, outcome),
    ).fetchone()[0]


def dispatch(root: Path, con: sqlite3.Connection, principal: Principal, project_id: str,
             component_id: str, payload: dict[str, Any]) -> dict:
    """Executa um componente somente se habilitado, permitido e autorizado."""
    entry = load_entry(root, component_id)
    if not entry["enabled"]:
        _record(con, entry, project_id, principal.principal_id, "denied_disabled")
        raise ComponentDisabled("componente desabilitado; nada foi iniciado", component_id=component_id)
    if project_id not in entry["allowed_projects"]:
        _record(con, entry, project_id, principal.principal_id, "denied_project")
        raise ComponentDisabled("componente não habilitado para este projeto", component_id=component_id)
    try:
        Policy(con).require(principal, "use", resource_project(project_id))
        proj_dir = project_root(root, con, principal, project_id, action="read")
    except FundacaoError:
        _record(con, entry, project_id, principal.principal_id, "denied_access")
        raise
    missing = [d for d in entry.get("requires_modules", []) if importlib.util.find_spec(d) is None]
    if missing:
        _record(con, entry, project_id, principal.principal_id, "denied_dependency")
        raise DependencyUnavailable("dependência ausente", component_id=component_id, missing=missing)
    module, func = entry["entrypoint"].split(":", 1)
    request = {"project_id": project_id, "project_dir": str(proj_dir), "payload": payload}
    # Ambiente mínimo: sem chaves nem tokens; só o que bibliotecas comuns exigem para rodar
    # (perfil, temporários e localidade — no Windows, torch/transformers precisam de USERNAME/USERPROFILE).
    env = {k: v for k, v in os.environ.items() if k in (
        "PATH", "SYSTEMROOT", "TEMP", "TMP", "TMPDIR", "USERNAME", "USERPROFILE", "HOME", "HOMEDRIVE",
        "HOMEPATH", "LOCALAPPDATA", "APPDATA", "LANG", "LC_ALL", "TZ")}
    env["PYTHONPATH"] = str(Path(root).resolve())
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    # Componente e subprocessos dele em UTF-8, mesmo com console cp1252 no Windows
    # (sem isso, texto acentuado podia virar saída vazia ou erro silencioso).
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    _record(con, entry, project_id, principal.principal_id, "executed")
    try:
        proc = subprocess.run(
            [sys.executable, "-m", "fundacao.core.runner", module, func],
            input=json.dumps(request), capture_output=True, text=True, encoding="utf-8",
            timeout=entry["timeout_seconds"], cwd=str(Path(root).resolve()), env=env,
        )
    except subprocess.TimeoutExpired:
        events.emit(con, "component_timeout", project_id=project_id, subject=principal.principal_id,
                    payload={"component_id": component_id})
        raise FundacaoError("tempo limite do componente excedido", component_id=component_id) from None
    if proc.returncode != 0:
        raise FundacaoError("componente falhou", component_id=component_id,
                            stderr=proc.stderr.strip()[-400:])
    result = json.loads(proc.stdout)
    events.emit(con, "component_executed", project_id=project_id, subject=principal.principal_id,
                payload={"component_id": component_id, "version": entry["version"]})
    return {"component_id": component_id, "version": entry["version"], "result": result}
